-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2016 at 09:39 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `footprints`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `ID` int(5) NOT NULL,
  `username` varchar(15) NOT NULL,
  `admin_name` text NOT NULL,
  `password` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone_number` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`ID`, `username`, `admin_name`, `password`, `email`, `phone_number`) VALUES
(1, 'Millitant', 'Millitant Saungweme', 'midzva', 'midzva@gmail.com', 775231654),
(2, 'Rasta', 'Onismo Bhasera', 'rasta', 'onismo@gmail.com', 774231343),
(3, 'Takudzwa', 'timmy', 'taku', 'timothytakudzwah@gmail.com', 774231343),
(0, 'Taurai', 'Taurai', 'taurai', 'taurai@gmail.com', 1225),
(0, 'Timothy', 'Timothy Ngorima', 'timmytak', 'timothytakudzwah@gmail.com', 774231343),
(0, 'Vannessa', 'Vanessa Vannessa', 'midza', 'm@gmail.com', 156);

-- --------------------------------------------------------

--
-- Table structure for table `advertiser`
--

CREATE TABLE IF NOT EXISTS `advertiser` (
  `username` varchar(15) NOT NULL,
  `advertiser_name` text NOT NULL,
  `password` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone_number` int(13) NOT NULL,
  `product_name` varchar(30) NOT NULL,
  `product_description` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `advertiser`
--

INSERT INTO `advertiser` (`username`, `advertiser_name`, `password`, `email`, `phone_number`, `product_name`, `product_description`) VALUES
('faraikh', 'Jokes', 'jlgilkm', 'timothytakudzwah@gmail.com', 0, 'Jokes', 'jpoadxcz'),
('Millitan', 'Millitant Saungwewme', 'hrh', 'millicent@gmail.com', 775231564, 'jngkj', 'kaxcok'),
('Millitant', 'Millitant Saungwewme', 'midzva', 'millicent@gmail.com', 775231564, 'dontknow', 'kaxcok'),
('Prudence', 'Bright Clothes', 'prudence', 'prudence@hotmail.com', 774258963, 'Bright Clothes', 'Clothes You will love'),
('Tafadzwa', 'Tafadzwa Mafura', '', 'someone@example.com', 774231343, 'vhgugii', 'dzemubhero'),
('Tafadzwah', 'Tafadzwa Mafura', 'timmytak', 'someone@example.com', 774231343, 'Clothes', 'dzemubhero'),
('Takudzwa', 'Timothy Ngorima', 'timmytak', 'timothytakudzwah@gmail.com', 774231343, 'clothes', 'igiugiiuou'),
('Timoth', 'Timothy Takudzwa Ngorima', 'igi', 'timothytakudzwah@gmail.com', 774231343, 'iih', 'dzinyowani'),
('Timothy', 'Tmothy Ngorima', 'timmytak', 'timothytakudzwah@gmail.com', 774231343, '', 'colognes'),
('Timotio', 'Jokes', 'timotio', 'timothytakudzwah@gmail.com', 0, 'Jokes', 'jpoadxcz'),
('Witness', 'Witness Ngwerume', 'witty', 'witty@hotmail.com', 2147483647, 'Hember', 'Cheap Clothes from Dubai');

-- --------------------------------------------------------

--
-- Table structure for table `adverts`
--

CREATE TABLE IF NOT EXISTS `adverts` (
  `advert_id` varchar(15) NOT NULL,
  `product_name` varchar(30) NOT NULL,
  `price` varchar(15) NOT NULL,
  `supplier_location` varchar(30) NOT NULL,
  `supplier_name` varchar(30) NOT NULL,
  `longitude` varchar(30) NOT NULL,
  `lattitude` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adverts`
--

INSERT INTO `adverts` (`advert_id`, `product_name`, `price`, `supplier_location`, `supplier_name`, `longitude`, `lattitude`) VALUES
('ADV112', 'Laptops', '$900.00', 'Joina City Mall', 'Econet Wireless', '1235', '1253');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `events_id` varchar(15) NOT NULL,
  `events_name` varchar(30) NOT NULL,
  `events_type` text NOT NULL,
  `events_start` date NOT NULL,
  `events_end` date NOT NULL,
  `events_organiser` varchar(20) NOT NULL,
  `events_description` varchar(500) NOT NULL,
  `location` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`events_id`, `events_name`, `events_type`, `events_start`, `events_end`, `events_organiser`, `events_description`, `location`) VALUES
('EVN001', 'Hackathon', 'Networking Event', '2016-05-14', '2015-05-15', 'Timothy', 'A competition of Software Engineers gathered to solve problems', 'Cresta Lodge'),
('EVN003', 'Team Building', 'Networking Event', '2016-04-02', '2016-04-03', 'Laravel', 'A Fun and Exciting recreating event for team building and stuff', 'TruoutBeck Resort'),
('EVN552', '8 Days of Glory', 'Networking Event', '2016-03-11', '2016-03-19', 'Believers Loveword M', '8 Days of Prayer and Worship organised by Belveder Christ Enbabssy Church in Zimbabwe with Invited guests coming from Canada, Texas, Ghana and Nigeria and these include Rev Ken Oyakhilome, Pastorr TT Edun, Pastor Siji Dara and Pastor Baidun Lawal', 'Belvedere Local Church');

-- --------------------------------------------------------

--
-- Table structure for table `events_organiser`
--

CREATE TABLE IF NOT EXISTS `events_organiser` (
  `username` varchar(15) NOT NULL,
  `name` varchar(30) NOT NULL,
  `password` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone_number` int(13) NOT NULL,
  `events_type` text NOT NULL,
  `description` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events_organiser`
--

INSERT INTO `events_organiser` (`username`, `name`, `password`, `email`, `phone_number`, `events_type`, `description`) VALUES
('Batsirai', 'Batsirai Ngorima', 'bwp', 'bwp@gmail.com', 2147483647, 'Musical', ''),
('Takudzwa', 'Takudzwa Ngorima', 'timmytak', 'timothytakudzwah@gmail.com', 774231343, 'tyu', '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(15) NOT NULL,
  `password` varchar(10) NOT NULL,
  `phone_number` int(13) NOT NULL,
  `email` varchar(30) NOT NULL,
  `events_interested_in` varchar(50) NOT NULL,
  `products_interested_in` varchar(50) NOT NULL,
  `current_location` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(3) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(10) NOT NULL,
  `user_role` text NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `user_role`, `name`) VALUES
(1, 'Takudzwa', 'timmy', 'organiser', 'Takudzwa Ngorima'),
(2, 'Timotio', 'timotio', 'organiser', 'Timmy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
 ADD PRIMARY KEY (`username`);

--
-- Indexes for table `advertiser`
--
ALTER TABLE `advertiser`
 ADD PRIMARY KEY (`username`);

--
-- Indexes for table `adverts`
--
ALTER TABLE `adverts`
 ADD PRIMARY KEY (`advert_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
 ADD PRIMARY KEY (`events_id`);

--
-- Indexes for table `events_organiser`
--
ALTER TABLE `events_organiser`
 ADD PRIMARY KEY (`username`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`username`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
