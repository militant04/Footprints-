/**
 * Created by Militant Saungweme on 5/21/2016.
 */


$(document).ready(function()
{

    $.getJSON("http://localhost:81/footprintss/eventjson.php" ,function(data)

    {


        $.each(data.result , function()
        {

            $("#date1").append("<span>"+this['event_day']+"</span>");
            $("#month1").append("<span>"+this['event_month']+"</span>");
            $("#name1").append("<span>"+this['event_name']+"</span>");
            $("#venue1").append("<span>"+this['venue_name']+"</span>");
            $("#img").append('<img src="http://localhost:81/footprintss/image/'+this['image']+'"    width="100%" height="100%"/>');

        });

    });

});